// Definimos la variables juegos como un entero idealmente positivo
var juegos = +prompt('¿Cuántas veces desea jugar?');
// Los puntos son inicializados en 0
var puntosUsuario = 0;
var puntosMaquina = 0;
// Un par de variables declaradas, pero no inicilizadas en esta parte
var jugadaUsuario;
var jugadaMaquina;
// Variables de texto inicilizadas como 'blancos'
var tipoJugadaUsuario = '';
var tipoJugadaMaquina = '';

// Ciclo preventivo en caso de no ingresar un entero positivo
// A pesar de que el profesor recomendó no usarlo, creo que aquí es prudente hacerlo
while (juegos <= 0) {
    juegos = +prompt('Por favor, ingrese un entero positivo');
}

// Ciclo en que se ingresan las jugadas del usuario y la máquina responde,
// con toda la lógica simplificada para resolver el desafío
for (var contador = 1; contador <= juegos; contador++) {
    jugadaUsuario = +prompt('Ingrese su jugada: 0 --> Piedra; 1 --> Papel; 2 --> Tijera');
    jugadaMaquina = Math.floor(Math.random() * 3);

    if (jugadaUsuario === 0) {
        tipoJugadaUsuario = 'Piedra';
    } else if (jugadaUsuario === 1) {
        tipoJugadaUsuario = 'Papel';
    } else if (jugadaUsuario === 2) {
        tipoJugadaUsuario = 'Tijera';
    } else {
        document.write(`Su jugada es incorrecta.<br>`);
    }

    if (jugadaMaquina === 0) {
        tipoJugadaMaquina = 'Piedra';
    } else if (jugadaMaquina === 1) {
        tipoJugadaMaquina = 'Papel';
    } else if (jugadaMaquina === 2) {
        tipoJugadaMaquina = 'Tijera';
    }

    document.write(`En el juego ${contador}, usted ha optado por <strong>${tipoJugadaUsuario}</strong> y la máquina <strong>${tipoJugadaMaquina}</strong>. `)

    if (jugadaUsuario === jugadaMaquina) {
        document.write(`En este juego hubo un <strong>empate</strong>. Marcador en este punto: usuario ${puntosUsuario}, máquina ${puntosMaquina}. <br>`);
    } else if (jugadaUsuario === 0 && jugadaMaquina === 1 || jugadaUsuario === 1 && jugadaMaquina === 2 || jugadaUsuario === 2 && jugadaMaquina === 0) {
        puntosMaquina++;
        document.write(`El punto es para la máquina. Marcador en este punto: usuario ${puntosUsuario}, máquina ${puntosMaquina}.<br>`);
    } else if (jugadaUsuario === 0 && jugadaMaquina === 2 || jugadaUsuario === 1 && jugadaMaquina === 0 || jugadaUsuario === 2 && jugadaMaquina === 1) {
        puntosUsuario++;
        document.write(`El punto es para usted. Marcador en este punto: usuario ${puntosUsuario}, máquina ${puntosMaquina}.<br>`);
    }
}

var resultados = document.getElementById('resultados');

if (puntosUsuario === puntosMaquina) {
    resultados.innerHTML = `<h4>La partida ha terminado empatada ${puntosUsuario} : ${puntosMaquina}.</h4>`
} else if (puntosUsuario < puntosMaquina) {
    resultados.innerHTML = `<h4>La máquina ha ganado ${puntosMaquina} : ${puntosUsuario}. Mejor suerte para la próxima vez.</h4>`;
} else {
    resultados.innerHTML = `<h2>Felicidades, usted ha ganado ${puntosUsuario} : ${puntosMaquina}.</h2>`
}